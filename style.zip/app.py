from flask import Flask, request, jsonify, send_from_directory
import sqlite3
import random

app = Flask(__name__)

DATABASE = "health.db"


@app.route("/")
def home():
    return send_from_directory(".", "index.html")


@app.route("/<path:filename>")
def serve_page(filename):
    return send_from_directory(".", filename)


@app.route("/api/profile", methods=["POST"])
def save_profile():
    data = request.get_json()

    name = data.get("name")
    age = data.get("age")
    gender = data.get("gender")
    height = data.get("height")
    weight = data.get("weight")
    diet = data.get("diet")
    activity = data.get("activity")
    goal = data.get("goal")

    if not all([
        name, age, gender, height,
        weight, diet, activity, goal
    ]):
        return jsonify({
            "success": False,
            "message": "All profile fields are required."
        }), 400

    connection = sqlite3.connect(DATABASE)
    cursor = connection.cursor()

    cursor.execute("""
        INSERT INTO users
        (name, age, gender, height, weight, diet, activity, goal)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?)
    """, (
        name,
        age,
        gender,
        height,
        weight,
        diet,
        activity,
        goal
    ))

    connection.commit()
    connection.close()

    return jsonify({
        "success": True,
        "message": "Profile saved successfully!"
    })
@app.route("/api/meal-plan", methods=["GET"])
def get_meal_plan():

    connection = sqlite3.connect(DATABASE)
    connection.row_factory = sqlite3.Row
    cursor = connection.cursor()

    cursor.execute("""
        SELECT name, age, gender, height, weight, diet, activity, goal
        FROM users
        ORDER BY rowid DESC
        LIMIT 1
    """)

    user = cursor.fetchone()
    connection.close()

    if not user:
        return jsonify({
            "success": False,
            "message": "No profile found."
        }), 404

    # User information
    diet = (user["diet"] or "").lower()
    goal = (user["goal"] or "").lower()

    age = float(user["age"])
    height = float(user["height"])
    weight = float(user["weight"])
    gender = (user["gender"] or "").lower()
    activity = (user["activity"] or "").lower()

    # -----------------------------
    # CALORIE CALCULATION
    # -----------------------------

    if gender == "female":
        bmr = (10 * weight) + (6.25 * height) - (5 * age) - 161
    else:
        bmr = (10 * weight) + (6.25 * height) - (5 * age) + 5

    activity_multiplier = 1.2

    if activity == "light":
        activity_multiplier = 1.375
    elif activity == "moderate":
        activity_multiplier = 1.55
    elif activity == "active":
        activity_multiplier = 1.725

    daily_calories = bmr * activity_multiplier

    if "lose" in goal or "loss" in goal:
        daily_calories -= 300
    elif "gain" in goal:
        daily_calories += 300

    daily_calories = round(daily_calories)

    breakfast_calories = round(daily_calories * 0.25)
    lunch_calories = round(daily_calories * 0.35)
    snack_calories = round(daily_calories * 0.15)
    dinner_calories = round(daily_calories * 0.25)

    # -----------------------------
    # VEGETARIAN MEALS
    # -----------------------------

    vegetarian_plans = [
        {
            "breakfast": {
                "name": "Vegetable Poha",
                "description": "Poha with vegetables, peanuts, and fresh fruit."
            },
            "lunch": {
                "name": "Dal, Roti & Salad",
                "description": "Whole-wheat roti, dal, vegetables, and fresh salad."
            },
            "snack": {
                "name": "Fruit & Yogurt",
                "description": "Fresh seasonal fruit with unsweetened yogurt."
            },
            "dinner": {
                "name": "Vegetable Khichdi",
                "description": "Light vegetable khichdi with curd and cooked vegetables."
            }
        },
        {
            "breakfast": {
                "name": "Vegetable Upma",
                "description": "Vegetable upma with a serving of fresh fruit."
            },
            "lunch": {
                "name": "Rajma Rice & Salad",
                "description": "Rajma with rice, vegetables, and fresh salad."
            },
            "snack": {
                "name": "Roasted Chana",
                "description": "A small serving of roasted chana with fruit."
            },
            "dinner": {
                "name": "Paneer Roti Bowl",
                "description": "Paneer with whole-wheat roti and cooked vegetables."
            }
        },
        {
            "breakfast": {
                "name": "Idli & Sambar",
                "description": "Steamed idli with vegetable sambar and fruit."
            },
            "lunch": {
                "name": "Chole Roti & Salad",
                "description": "Chole with whole-wheat roti and fresh salad."
            },
            "snack": {
                "name": "Fruit & Nuts",
                "description": "A seasonal fruit with a small handful of nuts."
            },
            "dinner": {
                "name": "Dal Khichdi",
                "description": "Dal khichdi with vegetables and a serving of curd."
            }
        }
    ]

    # -----------------------------
    # NON-VEGETARIAN MEALS
    # -----------------------------

    non_vegetarian_plans = [
        {
            "breakfast": {
                "name": "Egg & Vegetable Breakfast",
                "description": "Eggs with vegetables, whole-grain toast, and fruit."
            },
            "lunch": {
                "name": "Chicken, Roti & Salad",
                "description": "Lean chicken with whole-wheat roti and fresh salad."
            },
            "snack": {
                "name": "Fruit & Yogurt",
                "description": "Fresh fruit with unsweetened yogurt."
            },
            "dinner": {
                "name": "Chicken Vegetable Bowl",
                "description": "Lean chicken with cooked vegetables and whole grains."
            }
        },
        {
            "breakfast": {
                "name": "Vegetable Omelette",
                "description": "Egg omelette with vegetables and whole-grain toast."
            },
            "lunch": {
                "name": "Chicken Rice Bowl",
                "description": "Lean chicken with rice and mixed vegetables."
            },
            "snack": {
                "name": "Fruit & Nuts",
                "description": "Fresh fruit with a small serving of nuts."
            },
            "dinner": {
                "name": "Egg Curry & Roti",
                "description": "Egg curry with whole-wheat roti and vegetables."
            }
        },
        {
            "breakfast": {
                "name": "Boiled Eggs & Toast",
                "description": "Boiled eggs with whole-grain toast and fruit."
            },
            "lunch": {
                "name": "Chicken Dal & Roti",
                "description": "Lean chicken with dal, roti, and fresh salad."
            },
            "snack": {
                "name": "Yogurt & Fruit",
                "description": "Unsweetened yogurt with fresh seasonal fruit."
            },
            "dinner": {
                "name": "Grilled Chicken & Vegetables",
                "description": "Lean grilled chicken with cooked vegetables."
            }
        }
    ]

    # Select diet
    if "non" in diet:
        plans = non_vegetarian_plans
    else:
        plans = vegetarian_plans

    # Random plan
    meal_plan = random.choice(plans)

    # Weight-loss adjustment
    if "lose" in goal or "loss" in goal:
        meal_plan["snack"] = {
            "name": "Fruit & Yogurt",
            "description": "A light serving of fruit with unsweetened yogurt."
        }

        meal_plan["dinner"] = {
            "name": "Light Vegetable Dinner",
            "description": "A lighter portion of vegetables with a balanced protein and whole grain."
        }

    return jsonify({
        "success": True,

        "user": {
            "name": user["name"],
            "goal": user["goal"],
            "diet": user["diet"]
        },

        "daily_calories": daily_calories,

        "meals": {
            "breakfast": {
                **meal_plan["breakfast"],
                "calories": breakfast_calories
            },
            "lunch": {
                **meal_plan["lunch"],
                "calories": lunch_calories
            },
            "snack": {
                **meal_plan["snack"],
                "calories": snack_calories
            },
            "dinner": {
                **meal_plan["dinner"],
                "calories": dinner_calories
            }
        }
    })

# ===============================
# AI SYMPTOM WELLNESS GUIDE
# ===============================

@app.route("/api/symptoms", methods=["POST"])
def symptom_guide():

    data = request.get_json()

    if not data:
        return jsonify({
            "success": False,
            "message": "Please provide your symptoms."
        }), 400

    symptoms = data.get("symptoms", "").strip().lower()
    age = data.get("age")
    gender = data.get("gender")
    height = data.get("height")
    weight = data.get("weight")
    diet = data.get("diet")
    activity = data.get("activity")
    goal = data.get("goal")
    # Calculate BMI when profile information is available
    bmi = None

    try:
        if height and weight:
            height_m = float(height) / 100
            bmi = round(float(weight) / (height_m * height_m), 1)
    except (ValueError, TypeError, ZeroDivisionError):
        bmi = None
    # -----------------------------
    # URGENT SYMPTOM CHECK
    # -----------------------------

    urgent_words = [
        "chest pain",
        "difficulty breathing",
        "can't breathe",
        "cannot breathe",
        "severe bleeding",
        "unconscious",
        "fainted",
        "seizure",
        "stroke",
        "suicidal"
    ]

    if any(word in symptoms for word in urgent_words):

        return jsonify({
            "success": True,
            "guidance": (
                "Your description may include a potentially serious symptom. "
                "This application cannot assess emergencies or diagnose conditions. "
                "Please seek urgent medical attention or contact your local emergency service."
            )
        })

    if not symptoms:
        return jsonify({
            "success": False,
            "message": "Please describe your symptoms first."
        }), 400
    profile_note = ""

    if bmi is not None:
        profile_note += f" Your current BMI is {bmi}."

    if goal:
        profile_note += f" Your current health goal is {goal}."

    if activity:
        profile_note += f" Your activity level is {activity}."

    if diet:
        profile_note += f" Your diet preference is {diet}."

# -----------------------------
    # GENERAL WELLNESS GUIDANCE
    # -----------------------------

    if "tired" in symptoms or "fatigue" in symptoms or "low energy" in symptoms:

        guidance = (
            "Feeling tired can sometimes be related to insufficient sleep, "
            "dehydration, irregular meals, or a demanding day. "
            "Try drinking enough water, eating balanced meals, and getting "
            "adequate rest. If tiredness is persistent or severe, consider "
            "speaking with a healthcare professional."
        )

    elif "headache" in symptoms or "head pain" in symptoms:

        guidance = (
            "For a mild headache, consider resting, drinking water, and "
            "having a regular balanced meal if you have not eaten recently. "
            "Avoid skipping meals and pay attention to your hydration. "
            "If headaches are severe, sudden, frequent, or worsening, "
            "seek medical advice."
        )

    elif "fever" in symptoms or "temperature" in symptoms:

        guidance = (
            "If you have a fever, focus on rest and adequate fluid intake. "
            "Choose light, nutritious foods if you are able to eat. "
            "Monitor how you feel and seek medical advice if the fever is "
            "high, persistent, or accompanied by concerning symptoms."
        )

    elif "cold" in symptoms or "cough" in symptoms or "sore throat" in symptoms:

        guidance = (
            "For mild cold-like symptoms, stay hydrated and get adequate rest. "
            "Choose nutritious foods that are comfortable to eat. "
            "If symptoms become severe, persist, or you develop difficulty "
            "breathing, seek medical care."
        )

    elif "nausea" in symptoms or "vomit" in symptoms:

        guidance = (
            "If you feel mildly nauseated, try taking fluids slowly and "
            "choosing simple foods that you can tolerate. Avoid very heavy "
            "or greasy meals if they make you feel worse. "
            "Seek medical advice if vomiting is persistent or you cannot "
            "keep fluids down."
        )

    elif "dizzy" in symptoms or "dizziness" in symptoms:

        guidance = (
            "If you feel dizzy, sit or lie down somewhere safe and drink "
            "some water. Avoid driving or activities where you could fall. "
            "If dizziness is sudden, severe, persistent, or recurring, "
            "seek medical advice."
        )

    elif "stomach" in symptoms or "abdominal" in symptoms:

        guidance = (
            "For mild stomach discomfort, stay hydrated and consider "
            "smaller, simple meals. Avoid foods that you notice make your "
            "symptoms worse. If pain is severe, persistent, or worsening, "
            "seek medical attention."
        )

    elif "dehydrated" in symptoms or "dehydration" in symptoms:

        guidance = (
            "You may need more fluids. Drink water regularly and pay "
            "attention to your body's thirst. If you have severe weakness, "
            "confusion, fainting, or cannot keep fluids down, seek medical care."
        )

    else:

        guidance = (
            "Thank you for describing how you feel. Try to stay hydrated, "
            "eat balanced meals, get adequate rest, and monitor how your "
            "symptoms change. This wellness guide cannot diagnose illnesses "
            "or prescribe treatment. If your symptoms are severe, persistent, "
            "or worrying you, please consult a healthcare professional."
        )

    guidance += profile_note

    return jsonify({
        "success": True,
        "guidance": guidance
    })


if __name__=="__main__":
    app.run(debug=True)


